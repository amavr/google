﻿
var capp = null;

function PageInfo() {

    var me = this;

    me.box_log = null;
    me.btn1 = null;

    function constructor() {
        console.debug("PageInfo.constructor ");
        me.box_log = document.getElementById("box-log");
        me.btn1 = document.getElementById("btn1");
    }

    me.Log = function (html, crlf) {
        if (crlf === true) html += '<br/>';

        me.box_log.innerHTML += html;
    }

    constructor();
}

function ChromeApplication() {

    var me = this;

    var pi = null;

    var retrieveDriveFiles = function () {
        pi.Log("retrieveDriveFiles", true);
    }

    var onAuthComplete = function (result) {
        pi.Log("onAuthComplete", true);
        pi.Log(result.error, true);

        if (result && !result.error) {
            gapi.client.load('drive', 'v2', retrieveDriveFiles);
        }
    }

    var onClickBtn1 = function () {
        checkAuth(onAuthComplete);
    }

    me.Init = function () {
        console.debug("init");

        pi = new PageInfo();
        Event.add(pi.btn1, 'click', onClickBtn1);

        console.debug(pi);
        pi.Log("init complete", true);
    }

    var constructor = function () {
        me.Init();
    }

    constructor();

}

document.addEventListener('DOMContentLoaded', function () {
    capp = new ChromeApplication();
});
