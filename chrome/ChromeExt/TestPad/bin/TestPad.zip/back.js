﻿function test() {
    alert('test');
}