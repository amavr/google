﻿
var capp = null;

function PageInfo() {

    var me = this;

    me.box_log = null;
    me.btn1 = null;

    function constructor() {
        console.debug("PageInfo.constructor ");
        me.box_log = document.getElementById("box-log");
        me.btn1 = document.getElementById("btn1");
    }

    me.Log = function (html, crlf) {
        if (crlf === true) html += '<br/>';

        me.box_log.innerHTML += html;
    }

    constructor();
}

function ChromeApplication() {

    var me = this;

    var pi = null;

    var onClickBtn1 = function () {
        checkAuth();
        pi.Log("btn1 pressed", true);
    }

    me.Init = function () {
        console.debug("init");

        pi = new PageInfo();
        Event.add(pi.btn1, 'click', onClickBtn1);

        console.debug(pi);
    }

    var constructor = function () {
        me.Init();
    }

    constructor();

}

// Run our kitten generation script as soon as the document's DOM is ready.
document.addEventListener('DOMContentLoaded', function () {
    capp = new ChromeApplication();
    // capp.Init();
});
