﻿'use strict';

// var CLIENT_ID = '1039677446456-qoq16n6lcq8gt952dn0acrmfmf22ve1b.apps.googleusercontent.com';
//var CLIENT_ID = '458531844515-8aohg5151k1gdmfbt5762dpjcc25g9e9.apps.googleusercontent.com';
//var API_KEY = 'hofdfblhcmepaacojjjonbmheaphpnea';
var CLIENT_ID = '458531844515-b6l0cbrqpbllqa8gfvsa9ulu288krok9.apps.googleusercontent.com';
var API_KEY = 'AIzaSyAAdwcBLfjclphcokapqnSEEp2PX6Y6la0';

var SCOPES = [
	'https://www.googleapis.com/auth/drive',
];

var auth_callback = function (result) {
    console.debug(result);
};

function gapiLoad(callback) {
    if (callback) auth_callback = callback;

    gapi.client.setApiKey(API_KEY);
    // window.setTimeout(checkAuth, 1);
}

function checkAuth() {
    gapi.auth.authorize(
      { 'client_id': CLIENT_ID, 'scope': SCOPES, 'immediate': true },
      handleAuthResult);
}

function handleAuthResult(authResult) {

    var token = gapi.auth.getToken();
    console.log(token);

    if (authResult && !authResult.error) {
        auth_callback(authResult);
        // gapi.client.load('drive', 'v2', retrieveDriveFiles);
    }
    else {
        auth_callback(authResult);
        // alert(authResult.error + ': ' + authResult.error_subtype);

        console.log('No access token could be retrieved');

        gapi.auth.authorize(
			{
			    "client_id": CLIENT_ID,
			    "scope": SCOPES,
			    "immediate": false
			},
			handleAuthResult);
    }
}